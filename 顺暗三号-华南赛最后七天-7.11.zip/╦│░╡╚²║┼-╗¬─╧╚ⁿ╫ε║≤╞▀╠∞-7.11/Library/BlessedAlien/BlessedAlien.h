#ifndef __BlessedAlien
#define __BlessedAlien


extern const uint8 C6x8[][6]; // 6x8��ģ



#endif